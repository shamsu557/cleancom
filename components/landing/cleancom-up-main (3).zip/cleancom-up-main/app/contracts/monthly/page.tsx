"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { PageNavbar } from "@/components/navigation/page-navbar"
import { Footer } from "@/components/navigation/footer"
import { Calendar, Clock, MapPin, DollarSign, CheckCircle, AlertCircle } from "lucide-react"

export default function MonthlyContractPage() {
  const [dailyHours, setDailyHours] = useState("3")
  const [renewal, setRenewal] = useState("Auto-renew monthly")

  return (
    <div className="min-h-screen bg-background">
      <PageNavbar />

      <div className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">Monthly Cleaning Contract</h1>
            <p className="text-xl text-muted">Recurring monthly cleaning service with flexible terms and 5% discount</p>
          </div>

          {/* Benefits */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white rounded-lg border border-border p-6">
              <div className="text-3xl mb-3">⏱️</div>
              <h3 className="font-bold text-foreground mb-2">1-Month Term</h3>
              <p className="text-sm text-muted">Renewable monthly, no long-term commitment</p>
            </div>
            <div className="bg-white rounded-lg border border-border p-6">
              <div className="text-3xl mb-3">📊</div>
              <h3 className="font-bold text-foreground mb-2">5% Discount</h3>
              <p className="text-sm text-muted">Save 5% compared to one-time bookings</p>
            </div>
            <div className="bg-white rounded-lg border border-border p-6">
              <div className="text-3xl mb-3">💳</div>
              <h3 className="font-bold text-foreground mb-2">Flexible Payment</h3>
              <p className="text-sm text-muted">50% upfront, balance after 2 weeks</p>
            </div>
          </div>

          {/* Form */}
          <div className="bg-white rounded-lg border border-border p-8 shadow-sm mb-8">
            <div className="space-y-8">
              {/* Contract Details */}
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
                  <Calendar size={24} /> Contract Duration
                </h2>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Contract Start Date</label>
                    <input
                      type="date"
                      className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Renewal Option</label>
                    <select
                      value={renewal}
                      onChange={(e) => setRenewal(e.target.value)}
                      className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary appearance-none bg-white"
                    >
                      <option>Auto-renew monthly</option>
                      <option>Manual renewal required</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Work Schedule */}
              <div className="border-t border-border pt-8">
                <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
                  <Clock size={24} /> Weekly Schedule
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Select Working Days</label>
                    <div className="grid grid-cols-7 gap-2">
                      {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
                        <button
                          key={day}
                          className="p-3 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-colors font-medium text-sm"
                        >
                          {day}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6 mt-6">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Daily Hours</label>
                      <select
                        value={dailyHours}
                        onChange={(e) => setDailyHours(e.target.value)}
                        className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary appearance-none bg-white"
                      >
                        <option value="1">1 hour</option>
                        <option value="2">2 hours</option>
                        <option value="3">3 hours</option>
                        <option value="4">4 hours</option>
                        <option value="5">5+ hours</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Time Period</label>
                      <select className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary appearance-none bg-white">
                        <option>Morning (6 AM - 12 PM)</option>
                        <option>Afternoon (12 PM - 6 PM)</option>
                        <option>Evening (6 PM - 10 PM)</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Service Details */}
              <div className="border-t border-border pt-8">
                <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
                  <MapPin size={24} /> Service Information
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Location</label>
                    <input
                      type="text"
                      placeholder="Enter your address"
                      className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Number of Workers</label>
                      <select className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary appearance-none bg-white">
                        <option>1 worker</option>
                        <option>2 workers</option>
                        <option>3 workers</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Worker Gender Preference</label>
                      <select className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary appearance-none bg-white">
                        <option>No preference</option>
                        <option>Male</option>
                        <option>Female</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Pricing */}
              <div className="border-t border-border pt-8">
                <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
                  <DollarSign size={24} /> Monthly Pricing
                </h2>
                <div className="bg-gray-50 rounded-lg p-6 mb-6">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted">2 days/week × 3 hours × 1 worker × 4 weeks</span>
                      <span className="font-semibold text-foreground">240 BHD</span>
                    </div>
                    <div className="flex justify-between py-3 border-t border-border">
                      <span className="text-muted">Subtotal</span>
                      <span className="font-semibold text-foreground">240 BHD</span>
                    </div>
                    <div className="flex justify-between text-green-600">
                      <span>5% Monthly Discount</span>
                      <span>-12 BHD</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold text-primary border-t border-border pt-3">
                      <span>Total Cost</span>
                      <span>228 BHD</span>
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="text-sm font-medium text-blue-900 mb-2">50% Advance Payment</p>
                    <p className="text-2xl font-bold text-blue-900">114 BHD</p>
                    <p className="text-xs text-blue-800 mt-1">Due at contract signing</p>
                  </div>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <p className="text-sm font-medium text-green-900 mb-2">Balance Due</p>
                    <p className="text-2xl font-bold text-green-900">114 BHD</p>
                    <p className="text-xs text-green-800 mt-1">Due after 2 weeks of service</p>
                  </div>
                </div>
              </div>

              {/* Terms */}
              <div className="border-t border-border pt-8">
                <h2 className="text-2xl font-bold text-foreground mb-6">Important Terms</h2>
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <CheckCircle size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-muted">
                      <span className="font-medium text-foreground">48-hour Notice:</span> Modify schedule with 48 hours
                      notice
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <AlertCircle size={20} className="text-orange-600 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-muted">
                      <span className="font-medium text-foreground">Cancellation:</span> Less than 48 hours = 50%
                      charge, More than 48 hours = Full refund
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <CheckCircle size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-muted">
                      <span className="font-medium text-foreground">Automatic Renewal:</span> Contract auto-renews
                      unless cancelled 7 days before end date
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="flex gap-4">
            <Button variant="outline" size="lg">
              Cancel
            </Button>
            <Button size="lg">Sign Contract & Pay</Button>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
